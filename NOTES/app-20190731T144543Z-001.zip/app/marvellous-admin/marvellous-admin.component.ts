import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-admin',
  templateUrl: './marvellous-admin.component.html'
})
export class MarvellousAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
